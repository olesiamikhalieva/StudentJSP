CREATE FUNCTION timedate_pl(time without time zone, date)
  RETURNS timestamp without time zone
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select ($2 + $1)
$$;

