CREATE FUNCTION quote_literal(anyelement)
  RETURNS text
STABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.quote_literal($1::pg_catalog.text)
$$;

